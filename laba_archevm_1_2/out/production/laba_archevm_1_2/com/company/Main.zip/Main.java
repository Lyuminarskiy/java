package com.company;
import java.io.Console;
import java.util.Random;

class Main {
    public static void main(String[] args) {
        try {
            System.out.println("Пытаемся поделить на нуль...");
            double i = 6575/0;
        } catch (ArithmeticException ex){
            System.out.println("Обнаружена ошибка:\n     " + ex.toString());
        } finally {
            System.out.println("Наводим порядок перед завершением программы...");
        }
    }
}